package com.major.daoImpl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.major.dao.CdonateDao;
import com.major.pojo.Cdonatedata;
import com.major.pojo.User;

public class CdonateDaoImpl implements CdonateDao {
	@Override
	public List<Cdonatedata> getAllReqUsersDetail(){
		
		List<Cdonatedata> requList = new ArrayList<>();
		
		try 
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/major? useSSL=false","root","root");
			
			PreparedStatement pst = 
					con.prepareStatement(
			"select Did,donator_name,email,contact,city,"
			+ "address,cloth_type,cloth_count from"
			+ " cloth_donate where request like '1' and accept like '0';");
			
			ResultSet rs = pst.executeQuery();
			
			if(rs.isBeforeFirst())
			{
				while(rs.next())
				{
					Cdonatedata cd = new Cdonatedata();
					cd.setDonateid(rs.getInt("Did"));
					cd.setDonator_name(rs.getString("donator_name"));
					cd.setEmail(rs.getString("email"));
					cd.setContact(rs.getString("contact"));
					cd.setCity(rs.getString("city"));
					cd.setAddress(rs.getString("address"));
					cd.setCloth_type(rs.getString("cloth_type"));
					cd.setCloth_count(rs.getInt("cloth_count"));
					
					requList.add(cd);
				}
			}
			con.close();
			return requList;
		}
		catch(ClassNotFoundException| SQLException
				 exc) {
			exc.printStackTrace();
			requList.clear();
			return requList;
		}
	}
	
	@Override
	public List<Cdonatedata> getAllAcceptUsersDetail(){
		
		List<Cdonatedata> acptuList = new ArrayList<>();
		
		try 
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/major? useSSL=false","root","root");
			
			PreparedStatement pst = 
					con.prepareStatement(
			"select Did,donator_name,email,contact,city,"
			+ "address,cloth_type,cloth_count from"
			+ " cloth_donate where accept like '1' and donated like '0';");
			
			ResultSet rs = pst.executeQuery();
			
			if(rs.isBeforeFirst())
			{
				while(rs.next())
				{
					Cdonatedata cd = new Cdonatedata();
					cd.setDonateid(rs.getInt("Did"));
					cd.setDonator_name(rs.getString("donator_name"));
					cd.setEmail(rs.getString("email"));
					cd.setContact(rs.getString("contact"));
					cd.setCity(rs.getString("city"));
					cd.setAddress(rs.getString("address"));
					cd.setCloth_type(rs.getString("cloth_type"));
					cd.setCloth_count(rs.getInt("cloth_count"));
					
					acptuList.add(cd);
				}
			}
			con.close();
			return acptuList;
		}
		catch(ClassNotFoundException| SQLException
				 exc) {
			exc.printStackTrace();
			acptuList.clear();
			return acptuList;
		}
	}
	
	@Override
	public List<Cdonatedata> getAllDonatedUsersDetail(){
		
		List<Cdonatedata> dontuList = new ArrayList<>();
		
		try 
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/major? useSSL=false","root","root");
			
			PreparedStatement pst = 
					con.prepareStatement(
			"select Did,donator_name,email,contact,city,"
			+ "address,cloth_type,cloth_count from"
			+ " cloth_donate where donated like '1';");
			
			ResultSet rs = pst.executeQuery();
			
			if(rs.isBeforeFirst())
			{
				while(rs.next())
				{
					Cdonatedata cd = new Cdonatedata();
					cd.setDonateid(rs.getInt("Did"));
					cd.setDonator_name(rs.getString("donator_name"));
					cd.setEmail(rs.getString("email"));
					cd.setContact(rs.getString("contact"));
					cd.setCity(rs.getString("city"));
					cd.setAddress(rs.getString("address"));
					cd.setCloth_type(rs.getString("cloth_type"));
					cd.setCloth_count(rs.getInt("cloth_count"));
					
					dontuList.add(cd);
				}
			}
			con.close();
			return dontuList;
		}
		catch(ClassNotFoundException| SQLException
				 exc) {
			exc.printStackTrace();
			dontuList.clear();
			return dontuList;
		}
	}
	
	//-----------------------------------------------------
	@Override
	public boolean donate_reg(Cdonatedata donate) {
		try 
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/major? useSSL=false","root","root");
			PreparedStatement pst = 
					con.prepareStatement("INSERT INTO cloth_donate(donator_name,email,contact,city,address,cloth_type,cloth_count)"
							+ " VALUES(?,?,?,?,?,?,?)");
			
			pst.setString(1,donate.getDonator_name());
			pst.setString(2,donate.getEmail());
			pst.setString(3,donate.getContact());
			pst.setString(4,donate.getCity());
			pst.setString(5,donate.getAddress());
			pst.setString(6,donate.getCloth_type());
			pst.setInt(7,donate.getCloth_count());
			
			int count = pst.executeUpdate();
			con.close();
			if(count > 0)
				return true;
			else
				return false;
			
		}
		catch(SQLException | ClassNotFoundException exc) {
			exc.printStackTrace();
			return false;
		
		}
	}

}
