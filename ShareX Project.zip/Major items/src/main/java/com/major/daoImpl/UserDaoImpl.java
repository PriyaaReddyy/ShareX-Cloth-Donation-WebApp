package com.major.daoImpl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.major.dao.UserDao;
import com.major.pojo.User;
//import com.major.connection.DbConnection;
//import com.major.connection.DbConnection;

public class UserDaoImpl implements UserDao{
	@Override
	public boolean register(User user) {
		try 
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/major? useSSL=false","root","root");
			PreparedStatement pst = 
					con.prepareStatement("INSERT INTO user(uname,email,password,contact,city,state)"
							+ " VALUES(?,?,?,?,?,?)");
			
			pst.setString(1,user.getUsername());
			pst.setString(2,user.getEmail());
			pst.setString(3,user.getPassword());
			pst.setString(4,user.getContact());
			pst.setString(5,user.getCity());
			pst.setString(6,user.getState());
			
			int count = pst.executeUpdate();
			con.close();
			if(count > 0)
				return true;
			else
				return false;
			
		}
		catch(SQLException | ClassNotFoundException exc) {
			exc.printStackTrace();
			return false;
		
		}
	}
	
	
	@Override
	public boolean checkUser(User user) {
		try 
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/major? useSSL=false","root","root");
			
			PreparedStatement pst = 
				con.prepareStatement("SELECT * FROM user"
				+ " WHERE email = ? AND"
				+ " password = ?");
			
			pst.setString(1,user.getEmail());
			pst.setString(2,user.getPassword());
			
			ResultSet rs = pst.executeQuery();
			
			
			if(rs.isBeforeFirst())
			{	con.close();
				return true;
			}else
			{
				con.close();
				return false;
			}
		}
		catch(SQLException | ClassNotFoundException exc) {
			exc.printStackTrace();
			return false;
		}
	}
	
	@Override
	public List<User> getAllUsersDetail(){
		
		List<User> usersList = new ArrayList<>();
		
		try 
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/major? useSSL=false","root","root");
			
			PreparedStatement pst = 
					con.prepareStatement(
			"SELECT * FROM user");
			
			ResultSet rs = pst.executeQuery();
			
			if(rs.isBeforeFirst())
			{
				while(rs.next())
				{
					User u = new User();
					u.setUserid(rs.getInt("UID"));
					u.setUsername(
							rs.getString("uname"));
					u.setEmail(rs.getString("email"));
					u.setPassword(rs.getString("password"));
					u.setContact(
							rs.getString("contact"));
					u.setCity(rs.getString("city"));
					u.setState(rs.getString("state"));
					
					usersList.add(u);
				}
			}
			con.close();
			return usersList;
		}
		catch(ClassNotFoundException| SQLException
				 exc) {
			exc.printStackTrace();
			usersList.clear();
			return usersList;
		}
		
	}
}
