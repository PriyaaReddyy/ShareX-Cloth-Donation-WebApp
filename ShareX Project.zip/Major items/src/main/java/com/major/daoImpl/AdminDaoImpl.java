package com.major.daoImpl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.major.pojo.Admin;
import com.major.dao.AdminDao;

public class AdminDaoImpl implements AdminDao{
	@Override
	public boolean checkAdmin(Admin admin) {
		try 
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/major? useSSL=false","root","root");
			
			PreparedStatement pst = 
				con.prepareStatement("SELECT * FROM admin"
				+ " WHERE email = ? AND"
				+ " password = ?");
			
			pst.setString(1,admin.getEmail());
			pst.setString(2,admin.getPassword());
			
			ResultSet rs = pst.executeQuery();
			
			
			if(rs.isBeforeFirst())
			{	con.close();
				return true;
			}else
			{
				con.close();
				return false;
			}
		}
		catch(SQLException | ClassNotFoundException exc) {
			exc.printStackTrace();
			return false;
		}
	}
}
