package com.major.pojo;

public class Admin {
	private int adminid;
	private String orgname;
	private String contact;
	private String email;
	private String Address;
	private String username;
	private String password;
	private String managerName;
	private String managerContact;
	
	 Admin(int adminid,String orgname, String contact, String email, String address, String username, String password,
			String managerName, String managerContact) {
		this.adminid = adminid;
		this.orgname = orgname;
		this.contact = contact;
		this.email = email;
		this.Address = address;
		this.username = username;
		this.password = password;
		this.managerName = managerName;
		this.managerContact = managerContact;
	}

	 
	 
	public int getAdminid() {
		return adminid;
	}

	public Admin() {
	}

	public void setAdminid(int adminid) {
		this.adminid = adminid;
	}


	public String getOrgname() {
		return orgname;
	}

	public void setOrgname(String orgname) {
		this.orgname = orgname;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		Address = address;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getManagerName() {
		return managerName;
	}

	public void setManagerName(String managerName) {
		this.managerName = managerName;
	}

	public String getManagerContact() {
		return managerContact;
	}

	public void setManagerContact(String managerContact) {
		this.managerContact = managerContact;
	}
	
}