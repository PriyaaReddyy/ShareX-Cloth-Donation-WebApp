package com.major.pojo;

public class Cdonatedata {

	private int donateid;
	private String donator_name;
	private String email;
	private String contact;
	private String city;
	private String address;
	private String cloth_type;
	private int cloth_count;
	
	public Cdonatedata() {
		super();
	}

	public Cdonatedata(int donateid, String donator_name, String email, String contact, String city,
			String address, String cloth_type, int cloth_count) {
		super();
		this.donateid = donateid;
		this.donator_name = donator_name;
		this.email = email;
		this.contact = contact;
		this.city = city;
		this.address = address;
		this.cloth_type = cloth_type;
		this.cloth_count = cloth_count;
	}

	public int getDonateid() {
		return donateid;
	}
	
	public String getDonator_name() {
		return donator_name;
	}
	
	public String getEmail() {
		return email;
	}
	
	public String getContact() {
		return contact;
	}
	
	public String getCity() {
		return city;
	}
	
	public String getAddress() {
		return address;
	}
	
	public String getCloth_type() {
		return cloth_type;
	}
	
	public int getCloth_count() {
		return cloth_count;
	}
	
	public void setDonateid(int donateid) {
		this.donateid = donateid;
	}
	
	public void setDonator_name(String donator_name) {
		this.donator_name = donator_name;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	public void setContact(String contact) {
		this.contact = contact;
	}
	
	public void setCity(String city) {
		this.city = city;
	}
	
	public void setAddress(String address) {
		this.address = address;
	}
	
	public void setCloth_type(String cloth_type) {
		this.cloth_type = cloth_type;
	}
	
	public void setCloth_count(int cloth_count) {
		this.cloth_count = cloth_count;
	}

}
