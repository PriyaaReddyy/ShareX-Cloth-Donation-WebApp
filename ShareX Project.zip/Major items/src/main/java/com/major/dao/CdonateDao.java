package com.major.dao;
import java.util.List;
import com.major.pojo.Cdonatedata;
import com.major.pojo.User;


public interface CdonateDao {

	List<Cdonatedata> getAllReqUsersDetail();
	List<Cdonatedata> getAllAcceptUsersDetail();
	List<Cdonatedata> getAllDonatedUsersDetail();
	boolean donate_reg(Cdonatedata donate);
}
