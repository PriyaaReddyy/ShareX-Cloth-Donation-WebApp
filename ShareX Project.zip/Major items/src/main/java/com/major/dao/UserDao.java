package com.major.dao;
import java.util.List;

import com.major.pojo.User;

public interface UserDao {

	boolean register(User user);
	boolean checkUser(User user);
	List<User> getAllUsersDetail();
}
