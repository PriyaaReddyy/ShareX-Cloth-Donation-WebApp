package com.major.dao;

import com.major.pojo.Admin;

public interface AdminDao {
	boolean checkAdmin(Admin admin);
}
