package com.major.connection;

public interface DbDetails {

	String CONSTR = "jdbc:mysql://localhost:3306/sharex?useSSL=false&allowPublicKeyRetrieval=true";
	String USERNAME = "root";
	String PASSWORD = "root";
	String DBDRIVER = "com.mysql.cj.jdbc.Driver";
}
